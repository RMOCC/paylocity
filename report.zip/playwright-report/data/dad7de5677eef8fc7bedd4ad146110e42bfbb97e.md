# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api/employees.api.spec.ts >> DELETE /api/Employees/:id >> deletes employee and returns 404 after
- Location: tests/api/employees.api.spec.ts:219:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 404
Received: 200
```

# Test source

```ts
  122 |     expect((await createEmployee(request, { dependants: 1.5 })).status()).toBe(400);
  123 |   });
  124 | 
  125 |   // Dependants boundary: 0 (min), 32 (max), 33 (first invalid), -1 (negative)
  126 |   test('accepts 0 dependants (min)', async ({ request }) => {
  127 |     const { res } = await create(request, { dependants: 0 });
  128 |     expect(res.status()).toBe(200);
  129 |   });
  130 | 
  131 |   test('accepts 32 dependants (max)', async ({ request }) => {
  132 |     const { res } = await create(request, { dependants: 32 });
  133 |     expect(res.status()).toBe(200);
  134 |   });
  135 | 
  136 |   test('rejects 33 dependants', async ({ request }) => {
  137 |     expect((await createEmployee(request, { dependants: 33 })).status()).toBe(400);
  138 |   });
  139 | 
  140 |   test('rejects negative dependants', async ({ request }) => {
  141 |     expect((await createEmployee(request, { dependants: -1 })).status()).toBe(400);
  142 |   });
  143 | 
  144 |   // Name length boundary: 50 (valid), 51 (invalid)
  145 |   test('accepts firstName exactly 50 chars', async ({ request }) => {
  146 |     const { res } = await create(request, { firstName: 'A'.repeat(50) });
  147 |     expect(res.status()).toBe(200);
  148 |   });
  149 | 
  150 |   test('rejects firstName longer than 50 chars', async ({ request }) => {
  151 |     expect((await createEmployee(request, { firstName: 'A'.repeat(51) })).status()).toBe(400);
  152 |   });
  153 | 
  154 |   test('accepts lastName exactly 50 chars', async ({ request }) => {
  155 |     const { res } = await create(request, { lastName: 'B'.repeat(50) });
  156 |     expect(res.status()).toBe(200);
  157 |   });
  158 | 
  159 |   test('rejects lastName longer than 50 chars', async ({ request }) => {
  160 |     expect((await createEmployee(request, { lastName: 'B'.repeat(51) })).status()).toBe(400);
  161 |   });
  162 | });
  163 | 
  164 | test.describe('PUT /api/Employees', () => {
  165 |   let employee: any;
  166 |   test.beforeAll(async ({ request }) => {
  167 |     employee = await (await createEmployee(request, { firstName: 'Update', lastName: 'Me', dependants: 0 })).json();
  168 |   });
  169 |   test.afterAll(async ({ request }) => { await deleteEmployee(request, employee.id); });
  170 | 
  171 |   test('updates first name', async ({ request }) => {
  172 |     const res = await request.put(API_URL, { headers: authHeaders, data: { ...employee, firstName: 'Updated' } });
  173 |     expect(res.status()).toBe(200);
  174 |     expect((await res.json()).firstName).toBe('Updated');
  175 |   });
  176 | 
  177 |   test('recalculates benefits after dependant change', async ({ request }) => {
  178 |     const res = await request.put(API_URL, { headers: authHeaders, data: { ...employee, dependants: 4 } });
  179 |     const body = await res.json();
  180 |     expect(body.benefitsCost).toBeCloseTo(calculateBenefitsCost(4), 2);
  181 |     expect(body.net).toBeCloseTo(calculateNet(4), 2);
  182 |   });
  183 | 
  184 |   test('returns 400 for invalid dependants', async ({ request }) => {
  185 |     const res = await request.put(API_URL, { headers: authHeaders, data: { ...employee, dependants: 99 } });
  186 |     expect(res.status()).toBe(400);
  187 |   });
  188 | });
  189 | 
  190 | test.describe('Business logic — full payroll calculation', () => {
  191 |   let id: string;
  192 |   test.afterAll(async ({ request }) => { await deleteEmployee(request, id); });
  193 | 
  194 |   test('employee with 3 dependants: annual cost breaks down correctly into per-paycheck deduction', async ({ request }) => {
  195 |     const res = await createEmployee(request, { firstName: 'Business', lastName: 'Logic', dependants: 3 });
  196 |     const body = await res.json();
  197 |     id = body.id;
  198 | 
  199 |     // Annual gross: $2,000 per paycheck × 26 paychecks
  200 |     expect(body.gross).toBeCloseTo(2000 * 26, 2);                    // $52,000
  201 | 
  202 |     // Annual benefits: employee flat fee + 3 dependants
  203 |     const annualBenefits = 1000 + 3 * 500;                          // $2,500
  204 | 
  205 |     // Per-paycheck deduction: annual benefits spread over 26 paychecks
  206 |     expect(body.benefitsCost).toBeCloseTo(annualBenefits / 26, 2);  // ≈ $96.15
  207 | 
  208 |     // Net per paycheck: salary minus deduction
  209 |     expect(body.net).toBeCloseTo(2000 - annualBenefits / 26, 2);    // ≈ $1,903.85
  210 | 
  211 |     // Sanity: all four values are internally consistent
  212 |     expect(body.salary + body.gross + body.benefitsCost + body.net).toBeGreaterThan(0);
  213 |     expect(body.net).toBeLessThan(body.salary);
  214 |     expect(body.gross).toBeGreaterThan(body.salary);
  215 |   });
  216 | });
  217 | 
  218 | test.describe('DELETE /api/Employees/:id', () => {
  219 |   test('deletes employee and returns 404 after', async ({ request }) => {
  220 |     const { id } = await (await createEmployee(request, { firstName: 'Del', lastName: 'Me' })).json();
  221 |     expect((await deleteEmployee(request, id)).status()).toBe(200);
> 222 |     expect((await request.get(`${API_URL}/${id}`, { headers: authHeaders })).status()).toBe(404);
      |                                                                                        ^ Error: expect(received).toBe(expected) // Object.is equality
  223 |   });
  224 | 
  225 |   test('returns 404 for unknown id', async ({ request }) => {
  226 |     expect((await deleteEmployee(request, '00000000-0000-0000-0000-000000000001')).status()).toBe(404);
  227 |   });
  228 | });
  229 | 
```